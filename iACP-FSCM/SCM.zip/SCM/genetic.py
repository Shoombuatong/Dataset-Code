#
# genetic.py
#

import random
import sys
import os # markliou

MAXIMIZE, MINIMIZE = 11, 22
gen_score= []

class Individual(object):
    alleles = (0,1)
    length = 400
    seperator = ''
    optimization = MINIMIZE
    boundMAX = 1
    boundMIN = 0

    def __init__(self, chromosome=None):
        self.chromosome = chromosome or self._makechromosome()
        self.score = None  # set during evaluation
	self.kfoldacc = 0
    
    def _makechromosome(self):
        "makes a chromosome from randomly selected alleles."
        return [random.uniform(self.boundMIN,self.boundMAX) for gene in range(self.length)]

    def evaluate(self, optimum=None):
        "this method MUST be overridden to evaluate individual fitness score."
        pass
    
    def crossover(self, other):
        "override this method to use your preferred crossover method."
        return self._twopoint(other)
    
    def mutate(self, gene):
        "override this method to use your preferred mutation method."
        self._pick(gene) 
    
    # sample mutation method
    def _pick(self, gene):
        "chooses a random allele to replace this gene's allele."
        self.chromosome[gene] = random.choice(self.alleles)
    
    # sample crossover method
    def _twopoint(self, other):
        "creates offspring via two-point crossover between mates."
        left, right = self._pickpivots()
        def mate(p0, p1):
            chromosome = p0.chromosome[:]
            chromosome[left:right] = p1.chromosome[left:right]
            child = p0.__class__(chromosome)
            child._repair(p0, p1)
            return child
        return mate(self, other), mate(other, self)

    # some crossover helpers ...
    def _repair(self, parent1, parent2):
        "override this method, if necessary, to fix duplicated genes."
        pass

    def _pickpivots(self):
        left = random.randrange(1, self.length-2)
        right = random.randrange(left, self.length-1)
        return left, right

    #
    # other methods
    #

    def __repr__(self):
        "returns string representation of self"
        return '<%s chromosome="%s" score=%s>' % \
               (self.__class__.__name__,
                self.seperator.join(map(str,self.chromosome)), self.score)

    def __cmp__(self, other):
        if self.optimization == MINIMIZE:
            return cmp(self.score, other.score)
        else: # MAXIMIZE
            return cmp(other.score, self.score)
    
    def copy(self):
        twin = self.__class__(self.chromosome[:])
        twin.score = self.score
        return twin


class Environment(object):
    OutFileFlag = 0 ; #markliou
    output_scorecard =""; #markliou
    def __init__(self, kind, population=None, size=20, maxgenerations=100, 
                 crossover_rate=0.90, mutation_rate=0.01, optimum=None):
        self.kind = kind
        self.size = size
        self.optimum = optimum
        self.population = population or self._makepopulation()
        for individual in self.population:
            individual.evaluate(self.optimum)
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.maxgenerations = maxgenerations
        self.generation = 0
        self.report()

    def _makepopulation(self):
        return [self.kind() for individual in range(self.size)]
    
    def run(self):
        while not self._goal():
            self.step()
    
    def _goal(self):
        return self.generation > self.maxgenerations or \
               self.best.score == self.optimum
    
    def step(self):
	if self.generation != 0:
        	self.population.sort()
		self.population = self.population[:self.size]
        self._crossover()
        self.generation += 1
        self.report()
    
    def _crossover(self):
        next_population = [self.best.copy()]
        for i in range(self.size-1):
	    if self.generation == 0:
		mate1 = self.population[0]
	    else:
            	mate1 = self.best.copy()
            mate2 = self.population[i+1]
            offspring = mate1.crossover(mate2)
            self._mutate(offspring[0])
	    self._mutate(offspring[1])
            offspring[0].evaluate(self.optimum)
	    offspring[1].evaluate(self.optimum)
            next_population.append(offspring[0])
	    next_population.append(offspring[1])	
        self.population = next_population

    def _select(self):
        "override this to use your preferred selection method"
        return self._tournament()
    
    def _mutate(self, individual):
        for gene in range(individual.length):
            if random.random() < self.mutation_rate:
                individual.mutate(gene)

    #
    # sample selection method
    #
    def _tournament(self, size=8, choosebest=0.90):
        competitors = [random.choice(self.population) for i in range(size)]
        competitors.sort()
        if random.random() < choosebest:
            return competitors[0]
        else:
            return random.choice(competitors[1:])
    
    def best():
        doc = "individual with best fitness score in population."
        def fget(self):
            return self.population[0]
        return locals()
    best = property(**best())

    def report(self):
        print "="*70
        print "generation: ", self.generation
        print "best:       ", self.best
        #print self.best.score
        #print self.best.chromosome
		
        ### markliou for automatic testing existing file
        if self.OutFileFlag == 0 :
            ReportFileNo = 1 ;
            self.output_scorecard = "output_scorecard" + str(ReportFileNo)
            while os.path.exists(self.output_scorecard):
                ReportFileNo = ReportFileNo + 1
                self.output_scorecard = "output_scorecard" + str(ReportFileNo)
            self.OutFileFlag = 1 ;
        f12= file(self.output_scorecard, "w")
		##### markliou #####
		
        #f12= file("output_scorecard", "w")
        
        gen_score.append(self.best.score)
        f12.write("gen_score:"+"\t"+str(gen_score)+"\n")
        f12.write("best CV:"+"\t"+str(self.best.kfoldacc)+"\n")
        f12.write("best scoring:"+"\t"+str(100-self.best.score)+"\n")
        f12.write("best chromosome:"+"\t"+str(self.best.chromosome)+"\n"+"\n")


        
